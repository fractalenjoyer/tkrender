from .tkrender import *

__doc__ = tkrender.__doc__
if hasattr(tkrender, "__all__"):
    __all__ = tkrender.__all__